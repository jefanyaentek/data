<?php
$emailku = 'YOUREMAIL';
?>